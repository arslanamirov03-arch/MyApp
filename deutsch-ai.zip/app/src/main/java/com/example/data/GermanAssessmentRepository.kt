package com.example.data

import android.util.Base64
import com.example.BuildConfig
import com.example.network.Content
import com.example.network.GenerateContentRequest
import com.example.network.GenerateContentResponse
import com.example.network.GenerationConfig
import com.example.network.GermanAssessment
import com.example.network.InlineData
import com.example.network.Part
import com.example.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.io.File

import kotlinx.serialization.json.JsonPrimitive

class GermanAssessmentRepository {
    private val apiKey = BuildConfig.GEMINI_API_KEY
    private val json = RetrofitClient.jsonConfig

    suspend fun assessAudio(audioFile: File): Result<GermanAssessment> = withContext(Dispatchers.IO) {
        try {
            val audioBytes = audioFile.readBytes()
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            
            val request = GenerateContentRequest(
                systemInstruction = Content(
                    parts = listOf(Part(text = "You are an expert German language tutor and examiner. The user will provide an audio recording of them speaking German. Your task is to analyze their speech and provide a detailed assessment according to the CEFR levels. You MUST respond in pure JSON matching the provided schema. Speak strictly in Russian for the 'overallFeedback', 'pros', 'cons', 'strengths', 'weaknesses', 'recommendations', and 'nextLevelAdvice' fields. The 'transcript' should be the accurate transcription of what they said in German. Identify the exact CEFR level ('A1', 'A2', 'B1', 'B2', 'C1', 'C2') in the 'level' field. Fill 'confidence' with a number from 0 to 100."))
                ),
                contents = listOf(
                    Content(
                        parts = listOf(
                            Part(
                                inlineData = InlineData(
                                    mimeType = "audio/mp4", // works for most m4a/aac recordings
                                    data = base64Audio
                                )
                            )
                        )
                    )
                ),
                generationConfig = GenerationConfig(
                    responseMimeType = "application/json",
                    responseSchema = buildAssessmentSchema()
                )
            )

            val response = RetrofitClient.service.generateContent(apiKey, request)
            parseResponse(response)
        } catch (e: retrofit2.HttpException) {
            e.printStackTrace()
            if (e.code() == 429) {
                Result.failure(Exception("Превышен лимит запросов к ИИ (HTTP 429). Пожалуйста, подождите минуту и попробуйте снова."))
            } else {
                Result.failure(Exception("Ошибка сети: ${e.code()} ${e.message()}"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    suspend fun reAssessTranscript(transcript: String): Result<GermanAssessment> = withContext(Dispatchers.IO) {
        try {
            val request = GenerateContentRequest(
                systemInstruction = Content(
                    parts = listOf(Part(text = "You are an expert German language tutor and examiner. The user will provide a corrected text transcript of them speaking German. Your task is to analyze their text and provide a detailed assessment according to the CEFR levels. You MUST respond in pure JSON matching the provided schema. Use Russian for feedback arrays and strings. Fill 'confidence' with a number from 0 to 100."))
                ),
                contents = listOf(
                    Content(
                        parts = listOf(
                            Part(text = transcript)
                        )
                    )
                ),
                generationConfig = GenerationConfig(
                    responseMimeType = "application/json",
                    responseSchema = buildAssessmentSchema()
                )
            )

            val response = RetrofitClient.service.generateContent(apiKey, request)
            parseResponse(response)
        } catch (e: retrofit2.HttpException) {
            e.printStackTrace()
            if (e.code() == 429) {
                Result.failure(Exception("Превышен лимит запросов к ИИ (HTTP 429). Пожалуйста, подождите минуту и попробуйте снова."))
            } else {
                Result.failure(Exception("Ошибка сети: ${e.code()} ${e.message()}"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }
    
    suspend fun sendChatMessage(history: List<Content>, message: String): Result<String> = withContext(Dispatchers.IO) {
        try {
             val newContents = history.toMutableList()
             newContents.add(Content(role = "user", parts = listOf(Part(text = message))))
             
             val request = GenerateContentRequest(
                contents = newContents
            )
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (reply != null) {
                Result.success(reply)
            } else {
                Result.failure(Exception("Empty response"))
            }
        } catch (e: retrofit2.HttpException) {
            e.printStackTrace()
            if (e.code() == 429) {
                Result.failure(Exception("Превышен лимит запросов к ИИ (HTTP 429). Пожалуйста, подождите минуту и попробуйте снова."))
            } else {
                Result.failure(Exception("Ошибка сети: ${e.code()} ${e.message()}"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    private fun parseResponse(response: GenerateContentResponse): Result<GermanAssessment> {
        val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
        return if (text != null) {
            try {
                // Ensure text is clean from markdown markers
                val cleanText = text.replace("```json", "").replace("```", "").trim()
                val assessment = json.decodeFromString<GermanAssessment>(cleanText)
                Result.success(assessment)
            } catch (e: Exception) {
                e.printStackTrace()
                Result.failure(Exception("Failed to decode JSON: ${e.message}"))
            }
        } else {
            Result.failure(Exception("Empty API Response"))
        }
    }

    private fun buildAssessmentSchema() = buildJsonObject {
        put("type", "OBJECT")
        putJsonObject("properties") {
            putJsonObject("transcript") { put("type", "STRING"); put("description", "German transcript") }
            putJsonObject("level") { put("type", "STRING"); put("description", "A1, A2, B1, B2, C1, or C2") }
            putJsonObject("confidence") { put("type", "INTEGER"); put("description", "0 to 100") }
            putJsonObject("overallFeedback") { put("type", "STRING"); put("description", "Detailed overall feedback in Russian") }
            putJsonObject("pros") {
                put("type", "ARRAY")
                putJsonObject("items") { put("type", "STRING") }
            }
            putJsonObject("cons") {
                put("type", "ARRAY")
                putJsonObject("items") { put("type", "STRING") }
            }
            putJsonObject("strengths") {
                put("type", "ARRAY")
                putJsonObject("items") { put("type", "STRING") }
            }
            putJsonObject("weaknesses") {
                put("type", "ARRAY")
                putJsonObject("items") { put("type", "STRING") }
            }
            putJsonObject("recommendations") {
                put("type", "ARRAY")
                putJsonObject("items") { put("type", "STRING") }
            }
            putJsonObject("nextLevelAdvice") {
                put("type", "ARRAY")
                putJsonObject("items") { put("type", "STRING") }
            }
        }
        putJsonArray("required") {
            add(JsonPrimitive("transcript"))
            add(JsonPrimitive("level"))
            add(JsonPrimitive("confidence"))
            add(JsonPrimitive("overallFeedback"))
            add(JsonPrimitive("pros"))
            add(JsonPrimitive("cons"))
            add(JsonPrimitive("strengths"))
            add(JsonPrimitive("weaknesses"))
            add(JsonPrimitive("recommendations"))
            add(JsonPrimitive("nextLevelAdvice"))
        }
    }
}
