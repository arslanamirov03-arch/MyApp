package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GermanAssessmentRepository
import com.example.network.Content
import com.example.network.GermanAssessment
import com.example.network.Part
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed class AssessmentState {
    object Idle : AssessmentState()
    object Analyzing : AssessmentState()
    data class Success(val assessment: GermanAssessment) : AssessmentState()
    data class Error(val message: String) : AssessmentState()
}

data class ChatMessage(val isUser: Boolean, val text: String)

class AppViewModel : ViewModel() {
    private val repository = GermanAssessmentRepository()

    private val _state = MutableStateFlow<AssessmentState>(AssessmentState.Idle)
    val state = _state.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages = _chatMessages.asStateFlow()
    
    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading = _isChatLoading.asStateFlow()

    // Gemini API expects the chat history matching the strict user-model-user-model roles.
    private var geminiHistory = mutableListOf<Content>()

    fun reset() {
        _state.value = AssessmentState.Idle
        _chatMessages.value = emptyList()
        geminiHistory.clear()
    }

    fun submitAudio(audioFile: File) {
        _state.value = AssessmentState.Analyzing
        viewModelScope.launch {
            val result = repository.assessAudio(audioFile)
            if (result.isSuccess) {
                val assessment = result.getOrThrow()
                _state.value = AssessmentState.Success(assessment)
                initializeChatContext(assessment)
            } else {
                val e = result.exceptionOrNull()
                _state.value = AssessmentState.Error(e?.message ?: "Unknown error")
            }
        }
    }

    fun resubmitTranscript(transcript: String) {
        _state.value = AssessmentState.Analyzing
        viewModelScope.launch {
            val result = repository.reAssessTranscript(transcript)
            if (result.isSuccess) {
                val assessment = result.getOrThrow()
                _state.value = AssessmentState.Success(assessment)
                initializeChatContext(assessment)
            } else {
                val e = result.exceptionOrNull()
                _state.value = AssessmentState.Error(e?.message ?: "Unknown error")
            }
        }
    }

    private fun initializeChatContext(assessment: GermanAssessment) {
        // Prepare context for the AI Chat mentor
        val sysCtx = """
            You are 'AI Mentor', an expert German tutor. You are chatting with a student.
            Their latest assessment results:
            Level: ${assessment.level} (${assessment.confidence}%)
            Transcript: "${assessment.transcript}"
            Pros: ${assessment.pros.joinToString("; ")}
            Cons: ${assessment.cons.joinToString("; ")}
            
            Answer their questions directly based on this context. Be concise, educational, and friendly. Explain grammatical rules cleanly. Respond in Russian.
        """.trimIndent()
        
        geminiHistory.clear()
        _chatMessages.value = emptyList()
        
        // Unfortunately standard GenerateContentRequest does not easily take SystemInstruction inside chat history 
        // without providing it in the GenerateContentRequest structure, but we can simulate it with a preliminary
        // role="user" / role="model" exchange.
        geminiHistory.add(Content(role = "user", parts = listOf(Part(text = sysCtx))))
        geminiHistory.add(Content(role = "model", parts = listOf(Part(text = "Понял! Я готов помочь пользователю с его немецким."))))
        
        // Add welcome message to UI
        _chatMessages.value = listOf(
            ChatMessage(isUser = false, text = "Привет! Я проанализировал твою речь. Если у тебя есть вопросы по ошибкам или правилам — спрашивай!")
        )
    }

    fun sendChatMessage(message: String) {
        if (message.isBlank()) return
        
        val currentMsgs = _chatMessages.value.toMutableList()
        currentMsgs.add(ChatMessage(isUser = true, text = message))
        _chatMessages.value = currentMsgs
        _isChatLoading.value = true

        viewModelScope.launch {
            val result = repository.sendChatMessage(geminiHistory, message)
            if (result.isSuccess) {
                val reply = result.getOrThrow()
                geminiHistory.add(Content(role = "user", parts = listOf(Part(text = message))))
                geminiHistory.add(Content(role = "model", parts = listOf(Part(text = reply))))
                
                val updatedMsgs = _chatMessages.value.toMutableList()
                updatedMsgs.add(ChatMessage(isUser = false, text = reply))
                _chatMessages.value = updatedMsgs
            } else {
                val updatedMsgs = _chatMessages.value.toMutableList()
                updatedMsgs.add(ChatMessage(isUser = false, text = "Произошла ошибка при получении ответа."))
                _chatMessages.value = updatedMsgs
            }
            _isChatLoading.value = false
        }
    }
}
