package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.network.GermanAssessment
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: AppViewModel,
    onNavigateHome: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    
    var showChat by remember { mutableStateOf(false) }
    
    // Staggered animation triggers
    var startAnim by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(100)
        startAnim = true
    }

    if (state !is AssessmentState.Success) {
        return // Should not be here 
    }
    
    val assessment = (state as AssessmentState.Success).assessment

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Результаты", color = DarkText) },
                navigationIcon = {
                    IconButton(onClick = onNavigateHome) {
                        Icon(Icons.Filled.ChevronLeft, contentDescription = "Back", tint = DarkText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SolidWhite)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showChat = true },
                containerColor = AccentPurple,
                contentColor = SolidWhite,
                icon = { Icon(Icons.Filled.AutoAwesome, "AI Tutor") },
                text = { Text("AI Наставник") }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 0)) + slideInVertically(tween(400, 0)) { it / 2 }) {
                    LevelCard(assessment)
                }
            }
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 100)) + slideInVertically(tween(400, 100)) { it / 2 }) {
                    TranscriptCard(assessment, viewModel)
                }
            }
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 200)) + slideInVertically(tween(400, 200)) { it / 2 }) {
                    FeedbackCard(assessment)
                }
            }
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 300)) + slideInVertically(tween(400, 300)) { it / 2 }) {
                    ProsConsCard(assessment)
                }
            }
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 400)) + slideInVertically(tween(400, 400)) { it / 2 }) {
                    StrengthsWeaknessesCard(assessment)
                }
            }
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 500)) + slideInVertically(tween(400, 500)) { it / 2 }) {
                    RecommendationsCard("Рекомендации", assessment.recommendations)
                }
            }
            item {
                AnimatedVisibility(visible = startAnim, enter = fadeIn(tween(400, 600)) + slideInVertically(tween(400, 600)) { it / 2 }) {
                    RecommendationsCard("Как перейти на следующий уровень", assessment.nextLevelAdvice, isTarget = true)
                }
            }
        }
        
        if (showChat) {
            ModalBottomSheet(
                onDismissRequest = { showChat = false },
                containerColor = SurfaceGray,
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ) {
                AIChatWindow(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LevelCard(assessment: GermanAssessment) {
    val levelColors = when (assessment.level.uppercase()) {
        "A1" -> listOf(Color(0xFF9E9E9E), Color(0xFF616161))
        "A2" -> listOf(SuccessGreen, Color(0xFF16A34A))
        "B1" -> listOf(AccentBlue, Color(0xFF2563EB))
        "B2" -> listOf(Color(0xFF6366F1), Color(0xFF4338CA)) // Indigo
        "C1" -> listOf(AccentPurple, Color(0xFF7E22CE)) // Purple
        "C2" -> listOf(AccentPink, Color(0xFFBE185D)) // Pink
        else -> listOf(AccentBlue, AccentPurple)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(levelColors))
            .padding(24.dp)
    ) {
        Column {
            Text(
                text = "Оценка уровня",
                color = SolidWhite.copy(alpha = 0.8f),
                style = MaterialTheme.typography.titleMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = assessment.level.uppercase(),
                    color = SolidWhite,
                    style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black)
                )
                Text(
                    text = "Уверенность: ${assessment.confidence}%",
                    color = SolidWhite.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { assessment.confidence / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = SolidWhite,
                trackColor = SolidWhite.copy(alpha = 0.3f),
            )
        }
    }
}

@Composable
fun TranscriptCard(assessment: GermanAssessment, viewModel: AppViewModel) {
    var isEditing by remember { mutableStateOf(false) }
    var editedText by remember { mutableStateOf(assessment.transcript) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SolidWhite)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Транскрибация", style = MaterialTheme.typography.titleLarge, color = DarkText)
                if (!isEditing) {
                    IconButton(onClick = { isEditing = true }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = AccentBlue)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            if (isEditing) {
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = { isEditing = false; editedText = assessment.transcript }) {
                        Text("Отмена")
                    }
                    Button(
                        onClick = {
                            isEditing = false
                            viewModel.resubmitTranscript(editedText)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)
                    ) {
                        Text("Обновить анализ")
                    }
                }
            } else {
                Text(
                    text = assessment.transcript,
                    style = MaterialTheme.typography.bodyLarge,
                    color = LightText
                )
            }
        }
    }
}

@Composable
fun FeedbackCard(assessment: GermanAssessment) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Общий отзыв", style = MaterialTheme.typography.titleLarge, color = DarkText)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = assessment.overallFeedback,
                style = MaterialTheme.typography.bodyLarge,
                color = DarkText.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun ProsConsCard(assessment: GermanAssessment) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SolidWhite)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Плюсы", style = MaterialTheme.typography.titleMedium, color = SuccessGreen)
                Spacer(modifier = Modifier.height(8.dp))
                assessment.pros.forEach { pro ->
                    Row(modifier = Modifier.padding(vertical = 4.dp)) {
                        Icon(Icons.Filled.CheckCircle, null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(pro, style = MaterialTheme.typography.bodyMedium, color = DarkText)
                    }
                }
            }
        }
        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SolidWhite)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Минусы", style = MaterialTheme.typography.titleMedium, color = ErrorRed)
                Spacer(modifier = Modifier.height(8.dp))
                assessment.cons.forEach { con ->
                    Row(modifier = Modifier.padding(vertical = 4.dp)) {
                        Icon(Icons.Filled.Error, null, tint = ErrorRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(con, style = MaterialTheme.typography.bodyMedium, color = DarkText)
                    }
                }
            }
        }
    }
}

@Composable
fun StrengthsWeaknessesCard(assessment: GermanAssessment) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = CardGreen)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Сильные стороны", style = MaterialTheme.typography.titleMedium, color = SuccessGreen)
                Spacer(modifier = Modifier.height(8.dp))
                assessment.strengths.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium, color = DarkText, modifier = Modifier.padding(vertical = 2.dp)) }
            }
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = CardOrange)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Слабые стороны (зоны роста)", style = MaterialTheme.typography.titleMedium, color = WarningOrange)
                Spacer(modifier = Modifier.height(8.dp))
                assessment.weaknesses.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium, color = DarkText, modifier = Modifier.padding(vertical = 2.dp)) }
            }
        }
    }
}

@Composable
fun RecommendationsCard(title: String, items: List<String>, isTarget: Boolean = false) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SolidWhite)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isTarget) {
                    Box(modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(AccentPink), contentAlignment = Alignment.Center) {
                        Text("🎯", fontSize = 18.sp) // Emoji or icon
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Text(title, style = MaterialTheme.typography.titleLarge, color = DarkText)
            }
            Spacer(modifier = Modifier.height(16.dp))
            items.forEachIndexed { index, item ->
                Row(modifier = Modifier.padding(vertical = 6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(AccentBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${index + 1}", style = MaterialTheme.typography.labelLarge, color = AccentBlue)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(item, style = MaterialTheme.typography.bodyLarge, color = LightText)
                }
            }
        }
    }
}
