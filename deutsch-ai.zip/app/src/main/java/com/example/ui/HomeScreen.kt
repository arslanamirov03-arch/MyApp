package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.audio.AudioRecorderHelper
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onNavigateToDashboard: () -> Unit
) {
    val context = LocalContext.current
    val recorderHelper = remember { AudioRecorderHelper(context) }
    var isRecording by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableStateOf(0) }

    val state by viewModel.state.collectAsState()

    LaunchedEffect(state) {
        if (state is AssessmentState.Success) {
            onNavigateToDashboard()
        }
    }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingSeconds = 0
            while (true) {
                delay(1000)
                recordingSeconds++
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                is AssessmentState.Analyzing -> {
                    AnalyzingView()
                }
                is AssessmentState.Error -> {
                    ErrorView((state as AssessmentState.Error).message) {
                        viewModel.reset()
                    }
                }
                else -> {
                    RecordingView(
                        isRecording = isRecording,
                        seconds = recordingSeconds,
                        onToggle = {
                            if (isRecording) {
                                recorderHelper.stopRecording()
                                isRecording = false
                                recorderHelper.getOutputFile()?.let { file ->
                                    viewModel.submitAudio(file)
                                }
                            } else {
                                val ok = recorderHelper.startRecording() != null
                                if (ok) isRecording = true
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun RecordingView(
    isRecording: Boolean,
    seconds: Int,
    onToggle: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRecording) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAnim"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Deutsch AI",
            style = MaterialTheme.typography.displayMedium,
            color = DarkText,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Говорите на немецком языке.\nЯ проанализирую вашу речь.",
            style = MaterialTheme.typography.bodyLarge,
            color = LightText,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 64.dp)
        )

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(200.dp)
        ) {
            if (isRecording) {
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .scale(pulse)
                        .clip(CircleShape)
                        .background(AccentPink.copy(alpha = 0.2f))
                )
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .scale(pulse * 1.1f)
                        .clip(CircleShape)
                        .background(AccentPink.copy(alpha = 0.3f))
                )
            }

            val iconGradient = if (isRecording) {
                Brush.linearGradient(listOf(ErrorRed, AccentPink))
            } else {
                Brush.linearGradient(listOf(AccentBlue, AccentPurple))
            }

            Box(
                modifier = Modifier
                    .size(100.dp)
                    .shadow(16.dp, CircleShape, spotColor = AccentPurple)
                    .clip(CircleShape)
                    .background(iconGradient)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onToggle
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = if (isRecording) "Stop Recording" else "Start Recording",
                    tint = SolidWhite,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(48.dp))

        if (isRecording) {
            val min = seconds / 60
            val sec = seconds % 60
            Text(
                text = String.format("%02d:%02d", min, sec),
                style = MaterialTheme.typography.headlineLarge.copy(fontFamily = FontFamily.Monospace),
                color = AccentPink
            )
            Text(
                text = "Запись идет... Нажмите чтобы остановить",
                style = MaterialTheme.typography.bodyMedium,
                color = LightText,
                modifier = Modifier.padding(top = 8.dp)
            )
        } else {
            Text(
                text = "Нажмите для начала записи",
                style = MaterialTheme.typography.bodyLarge,
                color = LightText
            )
        }
    }
}

@Composable
fun AnalyzingView() {
    val infiniteTransition = rememberInfiniteTransition(label = "spin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinAnim"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .graphicsLayer { rotationZ = rotation }
                .clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(100.dp),
                color = AccentPurple,
                trackColor = AccentBlue.copy(alpha = 0.2f),
                strokeWidth = 6.dp
            )
        }
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = "ИИ анализирует Вашу речь...",
            style = MaterialTheme.typography.titleMedium,
            color = DarkText
        )
        Text(
            text = "Это может занять несколько секунд",
            style = MaterialTheme.typography.bodyMedium,
            color = LightText,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
fun ErrorView(msg: String, onRetry: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(32.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Stop,
            contentDescription = "Error",
            tint = ErrorRed,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Произошла ошибка",
            style = MaterialTheme.typography.titleLarge,
            color = DarkText
        )
        Text(
            text = msg,
            style = MaterialTheme.typography.bodyMedium,
            color = LightText,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
        )
        Button(
            onClick = onRetry,
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Text("Попробовать снова")
        }
    }
}
