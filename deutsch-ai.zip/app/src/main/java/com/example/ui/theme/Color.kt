package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkText = Color(0xFF1E212B)
val LightText = Color(0xFF636A7A)
val SolidWhite = Color(0xFFFFFFFF)
val SurfaceGray = Color(0xFFF7F8FC)

val AccentBlue = Color(0xFF4A8BFF)
val AccentPurple = Color(0xFF8E54E9)
val AccentPink = Color(0xFFFF528E)

val SuccessGreen = Color(0xFF22C55E)
val WarningOrange = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

// Card Backgrounds
val CardGreen = Color(0xFFE8F7EC)
val CardOrange = Color(0xFFFCF3E5)
val CardBlue = Color(0xFFEAF2FF)

val BlurWhite = Color(0xD9FFFFFF) // 85% opacity
